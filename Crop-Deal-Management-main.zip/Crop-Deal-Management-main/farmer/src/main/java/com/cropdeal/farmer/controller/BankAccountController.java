package com.cropdeal.farmer.controller;

import com.cropdeal.farmer.model.BankAccount;
import com.cropdeal.farmer.service.BankAccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/bank-details")
public class BankAccountController {

    @Autowired
    private BankAccountService bankAccountService;

    @PostMapping
    public ResponseEntity<BankAccount> addBankAccount(@RequestBody BankAccount bankAccount) {
        BankAccount addedBankAccount = bankAccountService.addBankAccount(bankAccount);
        return new ResponseEntity<>(addedBankAccount, HttpStatus.CREATED);
    }

    @GetMapping("/farmer/{farmerId}")
    public ResponseEntity<BankAccount> getBankAccountByFarmerId(@PathVariable Long farmerId) {
        BankAccount bankAccount = bankAccountService.getBankAccountByFarmerId(farmerId);
        if (bankAccount != null) {
            return new ResponseEntity<>(bankAccount, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @PutMapping("/farmer/{farmerId}")
    public ResponseEntity<BankAccount> updateBankAccount(@PathVariable Long farmerId, @RequestBody BankAccount bankAccount) {
        BankAccount updatedBankAccount = bankAccountService.updateBankAccount(farmerId, bankAccount);
        if (updatedBankAccount != null) {
            return new ResponseEntity<>(updatedBankAccount, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @DeleteMapping("/farmer/{farmerId}")
    public ResponseEntity<Void> deleteBankAccount(@PathVariable Long farmerId) {
        bankAccountService.deleteBankAccount(farmerId);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
