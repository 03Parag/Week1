package com.cropdeal.farmer.controller;

import com.cropdeal.farmer.model.Receipt;
import com.cropdeal.farmer.service.ReceiptService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/receipts")
public class ReceiptController {

    @Autowired
    private ReceiptService receiptService;

    @PostMapping
    public ResponseEntity<Receipt> generateReceipt(@RequestBody Receipt receipt) {
        Receipt generatedReceipt = receiptService.generateReceipt(receipt);
        return new ResponseEntity<>(generatedReceipt, HttpStatus.CREATED);
    }

    @GetMapping("/farmer/{farmerId}")
    public ResponseEntity<List<Receipt>> getReceiptsByFarmerId(@PathVariable Long farmerId) {
        List<Receipt> receipts = receiptService.getReceiptsByFarmerId(farmerId);
        return new ResponseEntity<>(receipts, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Receipt> getReceiptById(@PathVariable Long id) {
        Receipt receipt = receiptService.getReceiptById(id);
        if (receipt != null) {
            return new ResponseEntity<>(receipt, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
}
