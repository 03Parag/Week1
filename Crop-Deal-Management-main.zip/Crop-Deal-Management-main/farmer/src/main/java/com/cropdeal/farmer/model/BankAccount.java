package com.cropdeal.farmer.model;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name = "bank_accounts")
public class BankAccount {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String accountNumber;
    private String ifscCode;
    private String bankName;

    private Double accountBalance;

    @OneToOne
    @JoinColumn(name = "farmer_id")
    private Farmer farmer;

    // Constructors, getters, and setters
}
