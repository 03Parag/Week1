package com.cropdeal.farmer.model;

import jakarta.persistence.*;

import lombok.Data;

import java.time.LocalDateTime;

@Entity
@Data
@Table(name = "receipts")
public class Receipt {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String cropType;
    private Double quantitySold;
    private Double pricePerUnit;
    private Double totalPrice;
    private LocalDateTime transactionDate;

    @ManyToOne
    @JoinColumn(name = "farmer_id")
    private Farmer farmer;

    // Constructors, getters, and setters
}
