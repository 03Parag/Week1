package com.cropdeal.farmer.service;

import com.cropdeal.farmer.model.Farmer;

public interface FarmerService {

    Farmer registerFarmer(Farmer farmer);

    Farmer getFarmerById(Long id);

    Farmer updateFarmer(Long id, Farmer farmer);

    boolean existsByEmail(String email);
}
