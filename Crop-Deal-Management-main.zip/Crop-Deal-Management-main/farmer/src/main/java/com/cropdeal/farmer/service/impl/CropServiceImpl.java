package com.cropdeal.farmer.service.impl;

import com.cropdeal.farmer.model.Crop;
import com.cropdeal.farmer.repository.CropRepository;
import com.cropdeal.farmer.service.CropService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CropServiceImpl implements CropService {

    @Autowired
    private CropRepository cropRepository;

    @Override
    public Crop publishCrop(Crop crop) {
        return cropRepository.save(crop);
    }

    @Override
    public List<Crop> getCropsByFarmerId(Long farmerId) {
        return cropRepository.findByFarmerId(farmerId);
    }

    @Override
    public Crop getCropById(Long id) {
        return cropRepository.findById(id).orElse(null);
    }

    @Override
    public Crop updateCrop(Long id, Crop crop) {
        Crop existingCrop = cropRepository.findById(id).orElse(null);
        if (existingCrop != null) {
            existingCrop.setType(crop.getType());
            existingCrop.setName(crop.getName());
            existingCrop.setQuantity(crop.getQuantity());
            existingCrop.setLocation(crop.getLocation());
            return cropRepository.save(existingCrop);
        }
        return null;
    }

    @Override
    public void deleteCrop(Long id) {
        cropRepository.deleteById(id);
    }
}
