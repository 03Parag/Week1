package com.cropdeal.farmer.controller;

import com.cropdeal.farmer.model.Farmer;
import com.cropdeal.farmer.service.FarmerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/farmers")
public class FarmerController {

    @Autowired
    private FarmerService farmerService;

    @PostMapping("/register")
    public ResponseEntity<Farmer> registerFarmer(@RequestBody Farmer farmer) {
        if (farmerService.existsByEmail(farmer.getEmail())) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
        Farmer registeredFarmer = farmerService.registerFarmer(farmer);
        return new ResponseEntity<>(registeredFarmer, HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Farmer> getFarmerById(@PathVariable Long id) {
        Farmer farmer = farmerService.getFarmerById(id);
        if (farmer != null) {
            return new ResponseEntity<>(farmer, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Farmer> updateFarmer(@PathVariable Long id, @RequestBody Farmer farmer) {
        Farmer updatedFarmer = farmerService.updateFarmer(id, farmer);
        if (updatedFarmer != null) {
            return new ResponseEntity<>(updatedFarmer, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
}
