package com.cropdeal.farmer.service;

import com.cropdeal.farmer.model.BankAccount;

public interface BankAccountService {

    BankAccount addBankAccount(BankAccount bankAccount);

    BankAccount getBankAccountByFarmerId(Long farmerId);

    BankAccount updateBankAccount(Long farmerId, BankAccount bankAccount);

    void deleteBankAccount(Long farmerId);
}
