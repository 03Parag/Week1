package com.cropdeal.farmer.service;

import com.cropdeal.farmer.model.Crop;

import java.util.List;

public interface CropService {

    Crop publishCrop(Crop crop);

    List<Crop> getCropsByFarmerId(Long farmerId);

    Crop getCropById(Long id);

    Crop updateCrop(Long id, Crop crop);

    void deleteCrop(Long id);
}
