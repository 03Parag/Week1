package com.cropdeal.farmer.service;

import com.cropdeal.farmer.model.Receipt;

import java.util.List;

public interface ReceiptService {

    Receipt generateReceipt(Receipt receipt);

    List<Receipt> getReceiptsByFarmerId(Long farmerId);

    Receipt getReceiptById(Long id);
}
