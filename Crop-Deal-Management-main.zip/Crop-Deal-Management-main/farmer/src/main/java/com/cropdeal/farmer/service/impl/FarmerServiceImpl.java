package com.cropdeal.farmer.service.impl;

import com.cropdeal.farmer.model.Farmer;
import com.cropdeal.farmer.repository.FarmerRepository;
import com.cropdeal.farmer.service.FarmerService;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

@Service
public class FarmerServiceImpl implements FarmerService {

    @Autowired
    private FarmerRepository farmerRepository;

    @Override
    public Farmer registerFarmer(Farmer farmer) {
        // Hash the password before saving
        farmer.setPassword(farmer.getPassword());
        return farmerRepository.save(farmer);
    }

    @Override
    public Farmer getFarmerById(Long id) {
        return farmerRepository.findById(id).orElse(null);
    }

    @Override
    public Farmer updateFarmer(Long id, Farmer farmer) {
        Farmer existingFarmer = farmerRepository.findById(id).orElse(null);
        if (existingFarmer != null) {
            existingFarmer.setFirstName(farmer.getFirstName());
            existingFarmer.setLastName(farmer.getLastName());
            existingFarmer.setEmail(farmer.getEmail());
            existingFarmer.setPhone(farmer.getPhone());
            return farmerRepository.save(existingFarmer);
        }
        return null;
    }

    @Override
    public boolean existsByEmail(String email) {
        return farmerRepository.existsByEmail(email);
    }
}
