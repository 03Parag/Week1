package com.cropdeal.farmer.service.impl;

import com.cropdeal.farmer.model.Receipt;
import com.cropdeal.farmer.repository.ReceiptRepository;
import com.cropdeal.farmer.service.ReceiptService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class ReceiptServiceImpl implements ReceiptService {

    @Autowired
    private ReceiptRepository receiptRepository;

    @Override
    public Receipt generateReceipt(Receipt receipt) {
        receipt.setTransactionDate(LocalDateTime.now());
        return receiptRepository.save(receipt);
    }

    @Override
    public List<Receipt> getReceiptsByFarmerId(Long farmerId) {
        return receiptRepository.findByFarmerId(farmerId);
    }

    @Override
    public Receipt getReceiptById(Long id) {
        return receiptRepository.findById(id).orElse(null);
    }
}
