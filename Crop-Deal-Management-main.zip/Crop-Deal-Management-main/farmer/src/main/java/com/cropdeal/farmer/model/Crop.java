package com.cropdeal.farmer.model;

import jakarta.persistence.*;

import lombok.Data;

@Entity
@Data
@Table(name = "crops")
public class Crop {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String type; // vegetables/fruits
    private String name; // crop name
    private Double quantity;
    private String location;

    @ManyToOne
    @JoinColumn(name = "farmer_id")
    private Farmer farmer;

    // Constructors, getters, and setters
}
