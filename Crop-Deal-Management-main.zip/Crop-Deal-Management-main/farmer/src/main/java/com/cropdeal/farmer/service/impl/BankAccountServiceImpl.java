package com.cropdeal.farmer.service.impl;

import com.cropdeal.farmer.model.BankAccount;
import com.cropdeal.farmer.repository.BankAccountRepository;
import com.cropdeal.farmer.service.BankAccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BankAccountServiceImpl implements BankAccountService {

    @Autowired
    private BankAccountRepository bankAccountRepository;

    @Override
    public BankAccount addBankAccount(BankAccount bankAccount) {
        return bankAccountRepository.save(bankAccount);
    }

    @Override
    public BankAccount getBankAccountByFarmerId(Long farmerId) {
        return bankAccountRepository.findByFarmerId(farmerId).orElse(null);
    }

    @Override
    public BankAccount updateBankAccount(Long farmerId, BankAccount bankAccount) {
        BankAccount existingBankAccount = bankAccountRepository.findByFarmerId(farmerId).orElse(null);
        if (existingBankAccount != null) {
            existingBankAccount.setAccountNumber(bankAccount.getAccountNumber());
            existingBankAccount.setIfscCode(bankAccount.getIfscCode());
            existingBankAccount.setBankName(bankAccount.getBankName());
            existingBankAccount.setAccountBalance(bankAccount.getAccountBalance());
            return bankAccountRepository.save(existingBankAccount);
        }
        return null;
    }

    @Override
    public void deleteBankAccount(Long farmerId) {
        BankAccount existingBankAccount = bankAccountRepository.findByFarmerId(farmerId).orElse(null);
        if (existingBankAccount != null) {
            bankAccountRepository.delete(existingBankAccount);
        }
    }
}
