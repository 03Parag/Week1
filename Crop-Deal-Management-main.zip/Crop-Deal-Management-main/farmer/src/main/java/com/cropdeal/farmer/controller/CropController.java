package com.cropdeal.farmer.controller;

import com.cropdeal.farmer.model.Crop;
import com.cropdeal.farmer.service.CropService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/crops")
public class CropController {

    @Autowired
    private CropService cropService;

    @PostMapping
    public ResponseEntity<Crop> publishCrop(@RequestBody Crop crop) {
        Crop publishedCrop = cropService.publishCrop(crop);
        return new ResponseEntity<>(publishedCrop, HttpStatus.CREATED);
    }

    @GetMapping("/farmer/{farmerId}")
    public ResponseEntity<List<Crop>> getCropsByFarmerId(@PathVariable Long farmerId) {
        List<Crop> crops = cropService.getCropsByFarmerId(farmerId);
        return new ResponseEntity<>(crops, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Crop> getCropById(@PathVariable Long id) {
        Crop crop = cropService.getCropById(id);
        if (crop != null) {
            return new ResponseEntity<>(crop, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Crop> updateCrop(@PathVariable Long id, @RequestBody Crop crop) {
        Crop updatedCrop = cropService.updateCrop(id, crop);
        if (updatedCrop != null) {
            return new ResponseEntity<>(updatedCrop, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCrop(@PathVariable Long id) {
        cropService.deleteCrop(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
