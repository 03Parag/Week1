package com.cropdeal.dealer.model;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name = "dealers")
public class Dealer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String firstName;
    private String lastName;
    private String email;
    private String password; // Store hashed password
    private String phone;

    // Constructors, getters, and setters
}
