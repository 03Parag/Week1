package com.cropdeal.dealer.service.impl;

import com.cropdeal.dealer.model.Invoice;
import com.cropdeal.dealer.repository.InvoiceRepository;
import com.cropdeal.dealer.service.InvoiceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Service
public class InvoiceServiceImpl implements InvoiceService {

    @Autowired
    private InvoiceRepository invoiceRepository;

    @Override
    public Invoice generateInvoice(Invoice invoice) {
        invoice.setInvoiceNumber(UUID.randomUUID().toString());
        invoice.setInvoiceDate(LocalDateTime.now());
        return invoiceRepository.save(invoice);
    }

    @Override
    public List<Invoice> getInvoicesByDealerId(Long dealerId) {
        return invoiceRepository.findByDealerId(dealerId);
    }

    @Override
    public Invoice getInvoiceById(Long id) {
        return invoiceRepository.findById(id).orElse(null);
    }
}
