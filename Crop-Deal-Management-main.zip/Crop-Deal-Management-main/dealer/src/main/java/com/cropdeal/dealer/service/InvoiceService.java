package com.cropdeal.dealer.service;

import com.cropdeal.dealer.model.Invoice;

import java.util.List;

public interface InvoiceService {

    Invoice generateInvoice(Invoice invoice);

    List<Invoice> getInvoicesByDealerId(Long dealerId);

    Invoice getInvoiceById(Long id);
}
