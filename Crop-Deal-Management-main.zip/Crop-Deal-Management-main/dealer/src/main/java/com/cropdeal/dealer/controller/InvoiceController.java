package com.cropdeal.dealer.controller;

import com.cropdeal.dealer.model.Invoice;
import com.cropdeal.dealer.service.InvoiceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/invoices")
public class InvoiceController {

    @Autowired
    private InvoiceService invoiceService;

    @PostMapping
    public ResponseEntity<Invoice> generateInvoice(@RequestBody Invoice invoice) {
        Invoice generatedInvoice = invoiceService.generateInvoice(invoice);
        return new ResponseEntity<>(generatedInvoice, HttpStatus.CREATED);
    }

    @GetMapping("/dealer/{dealerId}")
    public ResponseEntity<List<Invoice>> getInvoicesByDealerId(@PathVariable Long dealerId) {
        List<Invoice> invoices = invoiceService.getInvoicesByDealerId(dealerId);
        return new ResponseEntity<>(invoices, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Invoice> getInvoiceById(@PathVariable Long id) {
        Invoice invoice = invoiceService.getInvoiceById(id);
        if (invoice != null) {
            return new ResponseEntity<>(invoice, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
}
