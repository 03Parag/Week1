package com.cropdeal.dealer.service.impl;

import com.cropdeal.dealer.model.CropSubscription;
import com.cropdeal.dealer.repository.CropSubscriptionRepository;
import com.cropdeal.dealer.service.CropSubscriptionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CropSubscriptionServiceImpl implements CropSubscriptionService {

    @Autowired
    private CropSubscriptionRepository cropSubscriptionRepository;

    @Override
    public CropSubscription subscribeCrop(CropSubscription subscription) {
        return cropSubscriptionRepository.save(subscription);
    }

    @Override
    public List<CropSubscription> getSubscriptionsByDealerId(Long dealerId) {
        return cropSubscriptionRepository.findByDealerId(dealerId);
    }

    @Override
    public void deleteSubscription(Long id) {
        cropSubscriptionRepository.deleteById(id);
    }
}
