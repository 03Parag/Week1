package com.cropdeal.dealer.service.impl;

import com.cropdeal.dealer.model.DealerBankAccount;
import com.cropdeal.dealer.repository.DealerBankAccountRepository;
import com.cropdeal.dealer.service.DealerBankAccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DealerBankAccountServiceImpl implements DealerBankAccountService {

    @Autowired
    private DealerBankAccountRepository dealerBankAccountRepository;

    @Override
    public DealerBankAccount addBankAccount(DealerBankAccount bankAccount) {
        return dealerBankAccountRepository.save(bankAccount);
    }

    @Override
    public DealerBankAccount getBankAccountByDealerId(Long dealerId) {
        return dealerBankAccountRepository.findByDealerId(dealerId).orElse(null);
    }

    @Override
    public DealerBankAccount updateBankAccount(Long dealerId, DealerBankAccount bankAccount) {
        DealerBankAccount existingBankAccount = dealerBankAccountRepository.findByDealerId(dealerId).orElse(null);
        if (existingBankAccount != null) {
            existingBankAccount.setAccountNumber(bankAccount.getAccountNumber());
            existingBankAccount.setIfscCode(bankAccount.getIfscCode());
            existingBankAccount.setBankName(bankAccount.getBankName());
            existingBankAccount.setAccountBalance(bankAccount.getAccountBalance());
            return dealerBankAccountRepository.save(existingBankAccount);
        }
        return null;
    }

    @Override
    public void deleteBankAccount(Long dealerId) {
        DealerBankAccount existingBankAccount = dealerBankAccountRepository.findByDealerId(dealerId).orElse(null);
        if (existingBankAccount != null) {
            dealerBankAccountRepository.delete(existingBankAccount);
        }
    }
}
