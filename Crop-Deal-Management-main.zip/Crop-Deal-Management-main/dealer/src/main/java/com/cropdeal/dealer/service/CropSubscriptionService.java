package com.cropdeal.dealer.service;

import com.cropdeal.dealer.model.CropSubscription;

import java.util.List;

public interface CropSubscriptionService {

    CropSubscription subscribeCrop(CropSubscription subscription);

    List<CropSubscription> getSubscriptionsByDealerId(Long dealerId);

    void deleteSubscription(Long id);
}
