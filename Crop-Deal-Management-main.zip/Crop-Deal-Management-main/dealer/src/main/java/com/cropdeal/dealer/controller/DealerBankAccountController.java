package com.cropdeal.dealer.controller;

import com.cropdeal.dealer.model.DealerBankAccount;
import com.cropdeal.dealer.service.DealerBankAccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/dealer-bank-details")
public class DealerBankAccountController {

    @Autowired
    private DealerBankAccountService dealerBankAccountService;

    @PostMapping
    public ResponseEntity<DealerBankAccount> addBankAccount(@RequestBody DealerBankAccount bankAccount) {
        DealerBankAccount addedBankAccount = dealerBankAccountService.addBankAccount(bankAccount);
        return new ResponseEntity<>(addedBankAccount, HttpStatus.CREATED);
    }

    @GetMapping("/dealer/{dealerId}")
    public ResponseEntity<DealerBankAccount> getBankAccountByDealerId(@PathVariable Long dealerId) {
        DealerBankAccount bankAccount = dealerBankAccountService.getBankAccountByDealerId(dealerId);
        if (bankAccount != null) {
            return new ResponseEntity<>(bankAccount, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @PutMapping("/dealer/{dealerId}")
    public ResponseEntity<DealerBankAccount> updateBankAccount(@PathVariable Long dealerId, @RequestBody DealerBankAccount bankAccount) {
        DealerBankAccount updatedBankAccount = dealerBankAccountService.updateBankAccount(dealerId, bankAccount);
        if (updatedBankAccount != null) {
            return new ResponseEntity<>(updatedBankAccount, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @DeleteMapping("/dealer/{dealerId}")
    public ResponseEntity<Void> deleteBankAccount(@PathVariable Long dealerId) {
        dealerBankAccountService.deleteBankAccount(dealerId);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
