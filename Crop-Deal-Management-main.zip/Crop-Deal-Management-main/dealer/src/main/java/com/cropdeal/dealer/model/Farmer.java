package com.cropdeal.dealer.model;

import lombok.Data;

@Data
public class Farmer {
    private Long id;
    private String firstName;
    private String lastName;
    private String email;
    private String phone;
    // Getters and setters
}
