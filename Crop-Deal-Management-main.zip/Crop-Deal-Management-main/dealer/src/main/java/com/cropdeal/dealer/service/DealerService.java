package com.cropdeal.dealer.service;

import com.cropdeal.dealer.model.Dealer;

public interface DealerService {

    Dealer registerDealer(Dealer dealer);

    Dealer getDealerById(Long id);

    Dealer updateDealer(Long id, Dealer dealer);

    boolean existsByEmail(String email);
}
