package com.cropdeal.dealer.model;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;

@Entity
@Data
@Table(name = "invoices")
public class Invoice {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String invoiceNumber;
    private LocalDateTime invoiceDate;
    private String cropType;
    private Double quantity;
    private Double pricePerUnit;
    private Double totalAmount;

    @ManyToOne
    @JoinColumn(name = "dealer_id")
    private Dealer dealer;

    // Constructors, getters, and setters
}
