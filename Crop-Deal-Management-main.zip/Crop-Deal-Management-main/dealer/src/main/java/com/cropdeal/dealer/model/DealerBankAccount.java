package com.cropdeal.dealer.model;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name = "dealer_bank_accounts")
public class DealerBankAccount {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String accountNumber;
    private String ifscCode;
    private String bankName;
    private Double accountBalance;

    @OneToOne
    @JoinColumn(name = "dealer_id")
    private Dealer dealer;

    // Constructors, getters, and setters
}
