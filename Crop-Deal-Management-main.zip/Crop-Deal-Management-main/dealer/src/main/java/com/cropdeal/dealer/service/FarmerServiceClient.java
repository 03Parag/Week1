package com.cropdeal.dealer.service;

import com.cropdeal.dealer.model.Farmer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class FarmerServiceClient {

    @Autowired
    private RestTemplate restTemplate;

    private final String farmerServiceUrl = "http://farmer-service/api/farmers/";

    public Farmer getFarmerById(Long farmerId) {
        return restTemplate.getForObject(farmerServiceUrl + farmerId, Farmer.class);
    }
}
