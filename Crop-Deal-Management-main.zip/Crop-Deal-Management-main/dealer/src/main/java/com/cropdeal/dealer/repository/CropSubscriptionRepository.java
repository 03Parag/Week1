package com.cropdeal.dealer.repository;

import com.cropdeal.dealer.model.CropSubscription;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CropSubscriptionRepository extends JpaRepository<CropSubscription, Long> {

    List<CropSubscription> findByDealerId(Long dealerId);
}
