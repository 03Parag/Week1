package com.cropdeal.dealer.service;

import com.cropdeal.dealer.model.DealerBankAccount;

public interface DealerBankAccountService {

    DealerBankAccount addBankAccount(DealerBankAccount bankAccount);

    DealerBankAccount getBankAccountByDealerId(Long dealerId);

    DealerBankAccount updateBankAccount(Long dealerId, DealerBankAccount bankAccount);

    void deleteBankAccount(Long dealerId);
}
