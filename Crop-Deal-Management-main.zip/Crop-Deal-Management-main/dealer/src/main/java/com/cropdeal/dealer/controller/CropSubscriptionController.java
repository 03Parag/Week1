package com.cropdeal.dealer.controller;

import com.cropdeal.dealer.model.CropSubscription;
import com.cropdeal.dealer.service.CropSubscriptionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/crop-subscriptions")
public class CropSubscriptionController {

    @Autowired
    private CropSubscriptionService cropSubscriptionService;

    @PostMapping
    public ResponseEntity<CropSubscription> subscribeCrop(@RequestBody CropSubscription subscription) {
        CropSubscription subscribedCrop = cropSubscriptionService.subscribeCrop(subscription);
        return new ResponseEntity<>(subscribedCrop, HttpStatus.CREATED);
    }

    @GetMapping("/dealer/{dealerId}")
    public ResponseEntity<List<CropSubscription>> getSubscriptionsByDealerId(@PathVariable Long dealerId) {
        List<CropSubscription> subscriptions = cropSubscriptionService.getSubscriptionsByDealerId(dealerId);
        return new ResponseEntity<>(subscriptions, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteSubscription(@PathVariable Long id) {
        cropSubscriptionService.deleteSubscription(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
