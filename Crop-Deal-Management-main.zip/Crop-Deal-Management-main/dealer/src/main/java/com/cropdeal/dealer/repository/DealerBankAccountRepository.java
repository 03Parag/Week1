package com.cropdeal.dealer.repository;

import com.cropdeal.dealer.model.DealerBankAccount;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface DealerBankAccountRepository extends JpaRepository<DealerBankAccount, Long> {

    Optional<DealerBankAccount> findByDealerId(Long dealerId);
}
