package com.cropdeal.dealer.model;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name = "crop_subscriptions")
public class CropSubscription {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String cropType;

    @ManyToOne
    @JoinColumn(name = "dealer_id")
    private Dealer dealer;

    // Constructors, getters, and setters
}
