package com.cropdeal.dealer.service.impl;

import com.cropdeal.dealer.model.Dealer;
import com.cropdeal.dealer.repository.DealerRepository;
import com.cropdeal.dealer.service.DealerService;
import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class DealerServiceImpl implements DealerService {

    @Autowired
    private DealerRepository dealerRepository;

//    @Autowired
//    private BCryptPasswordEncoder passwordEncoder;

    @Override
    public Dealer registerDealer(Dealer dealer) {
        // Hash the password before saving
        dealer.setPassword((dealer.getPassword()));
        return dealerRepository.save(dealer);
    }

    @Override
    public Dealer getDealerById(Long id) {
        return dealerRepository.findById(id).orElse(null);
    }

    @Override
    public Dealer updateDealer(Long id, Dealer dealer) {
        Dealer existingDealer = dealerRepository.findById(id).orElse(null);
        if (existingDealer != null) {
            existingDealer.setFirstName(dealer.getFirstName());
            existingDealer.setLastName(dealer.getLastName());
            existingDealer.setEmail(dealer.getEmail());
            existingDealer.setPhone(dealer.getPhone());
            return dealerRepository.save(existingDealer);
        }
        return null;
    }

    @Override
    public boolean existsByEmail(String email) {
        return dealerRepository.existsByEmail(email);
    }
}
