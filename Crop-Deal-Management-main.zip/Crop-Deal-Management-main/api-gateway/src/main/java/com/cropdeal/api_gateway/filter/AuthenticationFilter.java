package com.cropdeal.api_gateway.filter;

import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

import com.cropdeal.api_gateway.util.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.factory.AbstractGatewayFilterFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@Component
public class AuthenticationFilter extends AbstractGatewayFilterFactory<AuthenticationFilter.Config> {

    @Autowired
    private RouteValidator validator;

    @Autowired
    private JwtUtil jwtUtil;

    public AuthenticationFilter() {
        super(Config.class);
    }

    @Override
    public GatewayFilter apply(Config config) {
        return (exchange, chain) -> {
            if (validator.isSecured.test(exchange.getRequest())) {
                if (!exchange.getRequest().getHeaders().containsKey(HttpHeaders.AUTHORIZATION)) {
                    throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Missing Authorization Header");
                }

                String authHeader = exchange.getRequest().getHeaders().get(HttpHeaders.AUTHORIZATION).get(0);
                if (authHeader != null && authHeader.startsWith("Bearer ")) {
                    authHeader = authHeader.substring(7);
                }

                try {
                    jwtUtil.validateToken(authHeader);
                    String role = jwtUtil.extractRole(authHeader);

                    Map<String, String> rolePaths = new HashMap<>();
                    rolePaths.put("FARMER", "/farmer");
                    rolePaths.put("DEALER", "/dealer");
                    rolePaths.put("ADMIN", "/admin");

                    String path = exchange.getRequest().getPath().toString();
                    System.out.println("Path: " + path);

                    for (Map.Entry<String, String> entry : rolePaths.entrySet()) {
                        if (path.contains(entry.getValue()) && !role.equals(entry.getKey())) {
                            System.out.println("Access denied for " + entry.getValue() + " path");
                            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Access denied");
                        }
                    }

                } catch (Exception e) {
                    System.out.println("Token validation failed: " + e.getMessage());
                    throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Invalid or expired token: " + e.getMessage());
                }
            }

            return chain.filter(exchange);
        };
    }

    public static class Config {
    }
}
