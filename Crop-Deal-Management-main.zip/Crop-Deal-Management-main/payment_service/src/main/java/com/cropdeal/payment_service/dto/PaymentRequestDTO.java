package com.cropdeal.payment_service.dto;

import lombok.Data;

@Data
public class PaymentRequestDTO {
    private Long dealerId;
    private Long farmerId;
    private int amount;
    private String currency;
}
