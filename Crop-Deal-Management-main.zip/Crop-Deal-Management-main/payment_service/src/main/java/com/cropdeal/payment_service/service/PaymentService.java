package com.cropdeal.payment_service.service;

import com.cropdeal.payment_service.dto.PaymentRequestDTO;
import com.cropdeal.payment_service.model.PaymentTransaction;
import com.cropdeal.payment_service.repository.PaymentTransactionRepository;
import com.razorpay.Order;
import com.razorpay.RazorpayClient;
import com.razorpay.RazorpayException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class PaymentService {

    @Value("${razorpay.key_id}")
    private String apiKey;

    @Value("${razorpay.key_secret}")
    private String apiSecret;

    private final PaymentTransactionRepository transactionRepository;

    public PaymentService(PaymentTransactionRepository transactionRepository) {
        this.transactionRepository = transactionRepository;
    }

    public JSONObject createOrderAndSaveTransaction(PaymentRequestDTO request) throws RazorpayException {
        RazorpayClient razorpayClient = new RazorpayClient(apiKey, apiSecret);

        JSONObject orderRequest = new JSONObject();
        orderRequest.put("amount", request.getAmount() * 100);
        orderRequest.put("currency", request.getCurrency());
        orderRequest.put("receipt", "receipt_" + System.currentTimeMillis());

        Order order = razorpayClient.orders.create(orderRequest);

        // Save transaction to DB
        PaymentTransaction transaction = new PaymentTransaction();
        transaction.setDealerId(request.getDealerId());
        transaction.setFarmerId(request.getFarmerId());
        transaction.setAmount((double) request.getAmount());
        transaction.setStatus("PENDING");
        transaction.setRazorpayOrderId(order.get("id"));
        transaction.setCreatedAt(LocalDateTime.now());

        transactionRepository.save(transaction);

        return order.toJson();
    }

    public void updateTransactionWithPaymentId(String razorpayOrderId, String razorpayPaymentId) {

        PaymentTransaction transaction = transactionRepository.findByRazorpayOrderId(razorpayOrderId);
        if (transaction != null) {
            transaction.setRazorpayPaymentId(razorpayPaymentId);
            transaction.setStatus("SUCCESS");
            transactionRepository.save(transaction);
        }
    }
}
