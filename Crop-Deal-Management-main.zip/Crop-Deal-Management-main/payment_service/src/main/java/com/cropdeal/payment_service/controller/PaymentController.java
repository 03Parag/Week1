package com.cropdeal.payment_service.controller;

import com.cropdeal.payment_service.dto.PaymentRequestDTO;
import com.cropdeal.payment_service.dto.PaymentVerificationDTO;
import com.cropdeal.payment_service.service.PaymentService;
import com.razorpay.RazorpayException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/payments")
public class PaymentController {

    @Autowired
    private PaymentService paymentService;

    @PostMapping("/create-order")
    public ResponseEntity<?> createOrder(@RequestBody PaymentRequestDTO request) {
        try {
            JSONObject order = paymentService.createOrderAndSaveTransaction(request);
            return ResponseEntity.ok(order.toMap());
        } catch (RazorpayException e) {
            return ResponseEntity.status(500).body("Error while creating order: " + e.getMessage());
        }
    }
    @PostMapping("/verify")
    public ResponseEntity<?> verifyPayment(@RequestBody PaymentVerificationDTO verificationDTO) {
        paymentService.updateTransactionWithPaymentId(
                verificationDTO.getRazorpayOrderId(),
                verificationDTO.getRazorpayPaymentId()
        );
        return ResponseEntity.ok("Payment verified and updated in DB");
    }

}
