package com.cropdeal.payment_service.repository;


import com.cropdeal.payment_service.model.PaymentTransaction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PaymentTransactionRepository extends JpaRepository<PaymentTransaction, Long> {
    PaymentTransaction findByRazorpayOrderId(String razorpayOrderId);
}

