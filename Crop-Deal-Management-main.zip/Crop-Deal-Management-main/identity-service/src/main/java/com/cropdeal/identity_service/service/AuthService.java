package com.cropdeal.identity_service.service;

import com.cropdeal.identity_service.entity.UserCredential;
import com.cropdeal.identity_service.repository.UserCredentialRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthService {

    @Autowired
    private UserCredentialRepository repository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JwtService jwtService;

    public String saveUser(UserCredential credential) {
        credential.setPassword(passwordEncoder.encode(credential.getPassword()));
        repository.save(credential);
        return "User registered successfully";
    }

    public String generateToken(String userName) {
        UserCredential user = repository.findByUserName(userName).orElseThrow();
        return jwtService.generateToken(userName, user.getRole());
    }

    public void validateToken(String token) {
        jwtService.validateToken(token);
    }
}
