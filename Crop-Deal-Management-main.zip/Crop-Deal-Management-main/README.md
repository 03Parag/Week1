# 🌾 Crop Deal Management System

A **microservices-based platform** connecting **Farmers** directly with **Dealers**, streamlining the sale and purchase of agricultural produce with secure, scalable, and event-driven architecture.

## 🚀 Key Features

### 👨‍🌾 For Farmers
- Authentication & Profile Management
- Crop Publication/Management
- Bank Account Integration
- Receipt Generation after Sales

### 🧑‍💼 For Dealers
- Authentication & Profile Management
- Subscribe to Crop Notifications
- Place Orders for Available Crops

### 🛠️ For Admins
- User Management (Farmers & Dealers)
- Order Oversight & Advanced Reporting
- Administrative Controls (Activate/Deactivate Users)

---

## 🧱 Architecture Overview

- **Frontend**: Angular
- **Backend**: Spring Boot Microservices
- **Communication**:
  - REST for synchronous operations
  - RabbitMQ for asynchronous messaging
- **Service Discovery**: Eureka or Consul
- **Centralized Configuration**: Spring Cloud Config Server
- **Authentication**: OAuth 2.0 + JWT (with Federated Identity support)
- **Databases**: MySQL for each microservice

### 🏗️ Microservices Breakdown

#### 1. Farmer Microservice
- Crop management (publish/update/delete)
- Bank account handling
- Receipt generation
- Entities: `Farmer`, `Crop`, `BankAccount`, `Receipt`

#### 2. Dealer Microservice
- Subscription to crop notifications
- Order placement
- Entities: `Dealer`, `Order`

#### 3. Admin Microservice
- User and order management
- Reporting and dashboard functionality

---

## 🔁 Design Patterns Implemented

- **CQRS** – Separate read and write models
- **Event Sourcing** – Event logs instead of direct DB state change
- **Federated Identity** – Social login support (Google, Facebook)
- **Service Registry & Discovery** – Dynamic service interaction via Eureka
- **Externalized Configuration** – Config Server to centralize service configs

---

## 🧰 Tools & Technologies

| Category               | Tool/Framework           |
|------------------------|--------------------------|
| Backend                | Spring Boot              |
| Frontend               | React                  |
| Service Discovery      | Eureka / Consul          |
| Config Management      | Spring Cloud Config      |
| Messaging              | RabbitMQ                 |
| Security               | OAuth 2.0, JWT           |
| Persistence            | MySQL                    |
| Build Tool             | Maven / Gradle           |
| Version Control        | Git                      |

---

## 🧪 Sequence of Operations

### 📌 Farmer Publishes Crop
1. Farmer logs in via Angular
2. Sends crop data to Farmer MS
3. Data saved to MySQL
4. RabbitMQ sends notification to Dealers

### 📌 Dealer Places Order
1. Dealer logs in and views crop list
2. Places order → sent to Dealer MS
3. RabbitMQ emits event → triggers payment process
4. Receipt is generated for the Farmer