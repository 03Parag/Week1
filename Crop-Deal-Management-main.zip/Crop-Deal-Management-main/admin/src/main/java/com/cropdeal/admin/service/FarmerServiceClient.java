package com.cropdeal.admin.service;

import com.cropdeal.admin.model.Farmer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.List;

@Service
public class FarmerServiceClient {

    @Autowired
    private RestTemplate restTemplate;

    private String farmerServiceUrl = "http://farmer-service/api/farmers/";  // Eureka service name for Farmer Service

    public Farmer getFarmerById(Long farmerId) {
        return restTemplate.getForObject(farmerServiceUrl + farmerId, Farmer.class);
    }

    public List<Farmer> getAllFarmers() {
        Farmer[] farmers = restTemplate.getForObject(farmerServiceUrl, Farmer[].class);
        return Arrays.asList(farmers);
    }

    public Farmer updateFarmer(Long farmerId, Farmer farmer) {
        restTemplate.put(farmerServiceUrl + farmerId, farmer);
        return getFarmerById(farmerId);
    }

    public void deleteFarmer(Long farmerId) {
        restTemplate.delete(farmerServiceUrl + farmerId);
    }

    public void activateFarmer(Long farmerId) {
        restTemplate.put(farmerServiceUrl + farmerId + "/activate", null);
    }

    public void deactivateFarmer(Long farmerId) {
        restTemplate.put(farmerServiceUrl + farmerId + "/deactivate", null);
    }
}
