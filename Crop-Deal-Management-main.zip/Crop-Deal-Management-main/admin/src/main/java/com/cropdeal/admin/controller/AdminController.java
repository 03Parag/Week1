package com.cropdeal.admin.controller;

import com.cropdeal.admin.model.Admin;
import com.cropdeal.admin.model.Dealer;
import com.cropdeal.admin.model.Farmer;
import com.cropdeal.admin.service.AdminService;
import com.cropdeal.admin.service.DealerServiceClient;
import com.cropdeal.admin.service.FarmerServiceClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/admins")
public class AdminController {

    @Autowired
    private AdminService adminService;

    @Autowired
    private FarmerServiceClient farmerServiceClient;

    @Autowired
    private DealerServiceClient dealerServiceClient;

    @PostMapping("/register")
    public ResponseEntity<Admin> registerAdmin(@RequestBody Admin admin) {
        if (adminService.existsByEmail(admin.getEmail())) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
        Admin registeredAdmin = adminService.registerAdmin(admin);
        return new ResponseEntity<>(registeredAdmin, HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Admin> getAdminById(@PathVariable Long id) {
        Admin admin = adminService.getAdminById(id);
        if (admin != null) {
            return new ResponseEntity<>(admin, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Admin> updateAdmin(@PathVariable Long id, @RequestBody Admin admin) {
        Admin updatedAdmin = adminService.updateAdmin(id, admin);
        if (updatedAdmin != null) {
            return new ResponseEntity<>(updatedAdmin, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    // Farmer Management Endpoints
    @GetMapping("/farmers")
    public ResponseEntity<List<Farmer>> getAllFarmers() {
        List<Farmer> farmers = farmerServiceClient.getAllFarmers();
        return new ResponseEntity<>(farmers, HttpStatus.OK);
    }

    @GetMapping("/farmers/{farmerId}")
    public ResponseEntity<Farmer> getFarmerById(@PathVariable Long farmerId) {
        Farmer farmer = farmerServiceClient.getFarmerById(farmerId);
        if (farmer != null) {
            return new ResponseEntity<>(farmer, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @PutMapping("/farmers/{farmerId}")
    public ResponseEntity<Farmer> updateFarmer(@PathVariable Long farmerId, @RequestBody Farmer farmer) {
        Farmer updatedFarmer = farmerServiceClient.updateFarmer(farmerId, farmer);
        if (updatedFarmer != null) {
            return new ResponseEntity<>(updatedFarmer, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @DeleteMapping("/farmers/{farmerId}")
    public ResponseEntity<Void> deleteFarmer(@PathVariable Long farmerId) {
        farmerServiceClient.deleteFarmer(farmerId);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @PutMapping("/farmers/{farmerId}/activate")
    public ResponseEntity<Void> activateFarmer(@PathVariable Long farmerId) {
        farmerServiceClient.activateFarmer(farmerId);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @PutMapping("/farmers/{farmerId}/deactivate")
    public ResponseEntity<Void> deactivateFarmer(@PathVariable Long farmerId) {
        farmerServiceClient.deactivateFarmer(farmerId);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    // Dealer Management Endpoints
    @GetMapping("/dealers")
    public ResponseEntity<List<Dealer>> getAllDealers() {
        List<Dealer> dealers = dealerServiceClient.getAllDealers();
        return new ResponseEntity<>(dealers, HttpStatus.OK);
    }

    @GetMapping("/dealers/{dealerId}")
    public ResponseEntity<Dealer> getDealerById(@PathVariable Long dealerId) {
        Dealer dealer = dealerServiceClient.getDealerById(dealerId);
        if (dealer != null) {
            return new ResponseEntity<>(dealer, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @PutMapping("/dealers/{dealerId}")
    public ResponseEntity<Dealer> updateDealer(@PathVariable Long dealerId, @RequestBody Dealer dealer) {
        Dealer updatedDealer = dealerServiceClient.updateDealer(dealerId, dealer);
        if (updatedDealer != null) {
            return new ResponseEntity<>(updatedDealer, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @DeleteMapping("/dealers/{dealerId}")
    public ResponseEntity<Void> deleteDealer(@PathVariable Long dealerId) {
        dealerServiceClient.deleteDealer(dealerId);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @PutMapping("/dealers/{dealerId}/activate")
    public ResponseEntity<Void> activateDealer(@PathVariable Long dealerId) {
        dealerServiceClient.activateDealer(dealerId);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @PutMapping("/dealers/{dealerId}/deactivate")
    public ResponseEntity<Void> deactivateDealer(@PathVariable Long dealerId) {
        dealerServiceClient.deactivateDealer(dealerId);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
