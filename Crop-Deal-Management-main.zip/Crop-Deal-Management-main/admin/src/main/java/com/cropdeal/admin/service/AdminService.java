package com.cropdeal.admin.service;

import com.cropdeal.admin.model.Admin;

public interface AdminService {

    Admin registerAdmin(Admin admin);

    Admin getAdminById(Long id);

    Admin updateAdmin(Long id, Admin admin);

    boolean existsByEmail(String email);
}
