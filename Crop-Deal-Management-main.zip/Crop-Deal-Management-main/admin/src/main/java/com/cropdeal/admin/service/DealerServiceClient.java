package com.cropdeal.admin.service;

import com.cropdeal.admin.model.Dealer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.List;

@Service
public class DealerServiceClient {

    @Autowired
    private RestTemplate restTemplate;

    private String dealerServiceUrl = "http://dealer-service/api/dealers/";  // Eureka service name for Dealer Service

    public Dealer getDealerById(Long dealerId) {
        return restTemplate.getForObject(dealerServiceUrl + dealerId, Dealer.class);
    }

    public List<Dealer> getAllDealers() {
        Dealer[] dealers    = restTemplate.getForObject(dealerServiceUrl, Dealer[].class);
        return Arrays.asList(dealers);
    }

    public Dealer updateDealer(Long dealerId, Dealer dealer) {
        restTemplate.put(dealerServiceUrl + dealerId, dealer);
        return getDealerById(dealerId);
    }

    public void deleteDealer(Long dealerId) {
        restTemplate.delete(dealerServiceUrl + dealerId);
    }

    public void activateDealer(Long dealerId) {
        restTemplate.put(dealerServiceUrl + dealerId + "/activate", null);
    }

    public void deactivateDealer(Long dealerId) {
        restTemplate.put(dealerServiceUrl + dealerId + "/deactivate", null);
    }
}
