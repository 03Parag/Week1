package com.cropdeal.admin.service.impl;

import com.cropdeal.admin.model.Admin;
import com.cropdeal.admin.repository.AdminRepository;
import com.cropdeal.admin.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AdminServiceImpl implements AdminService {

    @Autowired
    private AdminRepository adminRepository;

//    @Autowired
//    private BCryptPasswordEncoder passwordEncoder;

    @Override
    public Admin registerAdmin(Admin admin) {
        // Hash the password before saving
        admin.setPassword(admin.getPassword());
        return adminRepository.save(admin);
    }

    @Override
    public Admin getAdminById(Long id) {
        return adminRepository.findById(id).orElse(null);
    }

    @Override
    public Admin updateAdmin(Long id, Admin admin) {
        Admin existingAdmin = adminRepository.findById(id).orElse(null);
        if (existingAdmin != null) {
            existingAdmin.setFirstName(admin.getFirstName());
            existingAdmin.setLastName(admin.getLastName());
            existingAdmin.setEmail(admin.getEmail());
            return adminRepository.save(existingAdmin);
        }
        return null;
    }

    @Override
    public boolean existsByEmail(String email) {
        return adminRepository.existsByEmail(email);
    }
}
