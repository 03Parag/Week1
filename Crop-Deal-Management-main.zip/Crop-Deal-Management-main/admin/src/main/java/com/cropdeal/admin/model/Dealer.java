package com.cropdeal.admin.model;

import lombok.Data;

@Data
public class Dealer {
    private Long id;
    private String firstName;
    private String lastName;
    private String email;
    private String phone;
    // Getters and setters
}
